//
//  hackSC_projApp.swift
//  hackSC-proj
//
//

import SwiftUI

@main
struct hackSC_projApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView
        }
    }
}
