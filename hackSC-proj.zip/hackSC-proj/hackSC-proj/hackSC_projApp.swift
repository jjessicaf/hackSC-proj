//
//  hackSC_projApp.swift
//  hackSC-proj
//
//  Created by Jessica Fu on 2/4/23.
//

import SwiftUI

@main
struct hackSC_projApp: App {
    var body: some Scene {
        WindowGroup {
            Loading()
            //ContentView
        }
    }
}
