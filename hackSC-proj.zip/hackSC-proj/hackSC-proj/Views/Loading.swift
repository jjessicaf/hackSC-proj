//
//  Loading.swift
//  hackSC-proj
//
//  Created by Jessica Fu on 2/4/23.
//

import SwiftUI
import UIKit

struct Loading: View {
    @State private var isActive = false
    @State private var size = 0.8
    @State private var opacity = 0.5
    @State private var off: Double = 25
    
    var body: some View {
        if (isActive) {
            Main()
        }
        else {
            VStack {
                VStack {
                    HStack {
                        HStack {
                            Circle().scaleEffect(0.2)
                            Circle().scaleEffect(0.2)
                            Circle().scaleEffect(0.2)
                            Circle().scaleEffect(0.2)
                            Circle().scaleEffect(0.2)
                        }.offset(y:35)
                        Image("Load2").scaleEffect(0.9).offset(y:10)
                    }.scaleEffect(0.8).offset(y:off)
                    .onAppear {
                        let baseAnimation = Animation.linear(duration: 1.5)
                        let repeated = baseAnimation.repeatForever(autoreverses: true)
                        withAnimation(repeated) {
                            off = 5
                        }
                    }
                    Text("LOADING")
                        .font(.largeTitle.bold()).foregroundColor(.black.opacity(0.80)).fontWeight(.bold).offset(y:5).scaleEffect(1.5)
                }.scaleEffect(size).opacity(opacity).onAppear {
                    withAnimation(.easeIn(duration: 1.5)) {
                        //self.size = 0.9
                        
                        self.opacity = 1.0
                    }
                }
            }
        }
        
        //Text("Hello, World!")
    }
}

struct Loading_Preview: PreviewProvider {
    static var previews: some View {
        Loading()
    }
}
