//
//  Main.swift
//  hackSC-proj
//
//  Created by Jessica Fu on 2/4/23.
//

import SwiftUI

struct Main: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct Main_Previews: PreviewProvider {
    static var previews: some View {
        Main()
    }
}
