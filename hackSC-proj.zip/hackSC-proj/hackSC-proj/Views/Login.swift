//
//  Login.swift
//  hackSC-proj
//
//  Created by Jessica Fu on 2/4/23.
//

import SwiftUI
import UIKit

struct Login: View {
    
    var body: some View {
        NavigationView {
            NavigationLink("Login Page") {
                Main()
            }
        }
        .padding()
    }
}

struct Login_Preview: PreviewProvider {
    static var previews: some View {
        Login()
    }
}
