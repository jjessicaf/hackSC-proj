//
//  chooseTheme2.swift
//  hackSC-proj
//
//  Created by Amy Zhang on 2/4/23.
//

import SwiftUI

struct chooseTheme2: View {
    private let colors: [Color] = [.green, .orange, .yellow]
    /*
    init(){
        let dino = Characters(id:0, name:"Dinosaur", color:.green)
        let mush = Characters(id:1, name:"Mushroom", color:.orange)
        let pot = Characters(id:2, name:"Potato", color:.blue)
        
        //let critters : [Characters] = [dino, mush, pot]
    }
     */
    //private let vals : [Int] = [0,1,2]
    private let photos :[String] = ["Dinosaur", "Mushroom", "Potato"]


    var body: some View {
        VStack {
            TabView {
                /*
                ForEach(vals, id: \.self) {val in ZStack {
                    colors[val]
                    Image(photos[val])
                }}
*/
                ForEach(photos, id: \.self) {photo in
                    ZStack {
                        Image(photo).scaleEffect(0.5)
                    }
                }

            
            }
            .tabViewStyle(.page(indexDisplayMode: .never))
            .padding(-500)
            .offset(y:400)
            Text ("CHOOSE YOUR")
                .multilineTextAlignment(.center)
                .font(.largeTitle.bold()).scaleEffect(1.3)
                .padding(.bottom, 5)
            Text ("THEME")
                .multilineTextAlignment(.center)
                .font(.largeTitle.bold()).scaleEffect(1.3)
                .padding(.bottom, 420)


            VStack{
                Button{
                    
                } label: {
                    Text("SELECT")
                        .frame(width:250, height:60)
                        .background(Color.white)
                        .clipShape(RoundedRectangle(cornerRadius: 30))
                        .font(.title)
                        .foregroundColor(Color.black).bold()
                        .overlay(
                            RoundedRectangle(cornerRadius:20)
                                .stroke(Color.black,lineWidth:4))
                }
            }
            .onTapGesture{
                Main()
            }
            .padding(.bottom, 80)
        }
    }
}


struct chooseTheme2_Previews: PreviewProvider {
    static var previews: some View {
        chooseTheme2()
    }
}


