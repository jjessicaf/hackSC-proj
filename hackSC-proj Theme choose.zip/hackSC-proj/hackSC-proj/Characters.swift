//
//  Characters.swift
//  hackSC-proj
//
//  Created by Amy Zhang on 2/4/23.
//
/*
import Foundation
import SwiftUI

struct Characters: Hashable {
    var id: Int
    var name: String
    var color: Color

    var image: Image {
        Image(name)
    }
} */

