//
//  activity.swift
//  activity
//
//  Created by Ellie Xing on 2/4/23.
//

import Foundation
import UIKit

class activity: UIViewController {
    @IBAction func closepage(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        let date = Date()
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "MM/dd/yyyy"
        let dateString = dateFormatter.string(from: date)

        let label = UILabel(frame: CGRect(x: 0, y: 0, width: 150, height: 25))
        label.center = CGPoint(x: 200, y: 218)
        label.textAlignment = .center
        label.text = dateString
        self.view.addSubview(label)
    }
}

