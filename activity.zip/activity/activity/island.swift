//
//  island.swift
//  activity
//
//  Created by Ellie Xing on 2/4/23.
//

import UIKit

class island : UIViewController {

    @IBAction func closeisland(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

    }
}
