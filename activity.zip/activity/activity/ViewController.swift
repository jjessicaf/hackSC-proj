//
//  ViewController.swift
//  activity
//
//  Created by Ellie Xing on 2/4/23.
//

import UIKit

class ViewController: UIViewController {
    @IBAction func enterisland(_ sender: Any) {
        performSegue(withIdentifier: "gotoisland", sender: self)
    }
    
    @IBAction func mybutton(_ sender: Any) {
        performSegue(withIdentifier: "mysegue", sender: self)
    }
    
    
    @IBOutlet weak var character: UIImageView!
    

    override func viewDidLoad() {
        super.viewDidLoad()
        animateImage(character, offset: 20)
    }

    func animateImage(_ imageView: UIImageView, offset: CGFloat) {
        UIView.animate(withDuration: 0.5, delay: 0, options: [.repeat, .autoreverse], animations: {
            imageView.transform = CGAffineTransform(translationX: 0, y: offset)
        })
    }

}

